package com.cg.lab2.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import com.cg.lab2.dto.Trainee;


@Repository("traineedao")
public class TraineeDaoImpl implements ITraineeDao
{
	@PersistenceContext
	EntityManager em;
	@Override
	public int insertTrainee(Trainee trainee) 
	{
		em.persist(trainee);
		em.flush();
		return trainee.getTraineeId();
	}

	@Override
	public void deleteTrainee(int id) 
	{
		Query query1=em.createQuery("DELETE FROM Trainee WHERE traineeId=:tid");
		query1.setParameter("tid", id);
		query1.executeUpdate();
	}

	@Override
	public void updateTrainee(Trainee trainee) 
	{
		em.merge(trainee);


	}

	@Override
	public List<Trainee> showAllTrainee() 
	{
		Query q2 = em.createQuery("FROM Trainee");
		return q2.getResultList();
	}

	@Override
	public Trainee searchTrainee(int id)
	{
		String q1="SELECT trainee FROM Trainee trainee WHERE trainee.traineeId=:tid";
		TypedQuery<Trainee> query1=em.createQuery(q1,Trainee.class);
		query1.setParameter("tid", id);
		Trainee t=query1.getSingleResult();
		return t;
	}

}
