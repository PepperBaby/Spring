package com.cg.lab2.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.lab2.dao.ITraineeDao;
import com.cg.lab2.dto.Trainee;

@Service("traineeservice")
@Transactional
public class TraineeServiceImpl implements ITraineeService
{
	@Autowired
	ITraineeDao traineedao;
	@Override
	public int insertTrainee(Trainee trainee) 
	{
		
		return traineedao.insertTrainee(trainee);
	}

	@Override
	public void deleteTrainee(int id) 
	{
		 traineedao.deleteTrainee(id);
		
	}

	@Override
	public void updateTrainee(Trainee trainee) {
		// TODO Auto-generated method stub
		traineedao.updateTrainee(trainee);
	}

	@Override
	public List<Trainee> showAllTrainee() {
		// TODO Auto-generated method stub
		return traineedao.showAllTrainee();
	}

	@Override
	public Trainee searchTrainee(int id) {
		// TODO Auto-generated method stub
		return traineedao.searchTrainee(id);
	}
	
}
