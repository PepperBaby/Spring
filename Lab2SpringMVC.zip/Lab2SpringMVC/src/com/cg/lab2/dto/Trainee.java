package com.cg.lab2.dto;

import javax.persistence.*;

@Entity
@Table(name="traineemanagement")
public class Trainee 
{
	@Id
	@Column(name="Trainee_Id")
	private Integer traineeId;
	@Column(name="Trainee_Name")
	private String traineeName;
	@Column(name="Trainee_Domain")
	private String traineeDomain;
	@Column(name="Trainee_Location")
	private String traineeLocation;
	public Integer getTraineeId() {
		return traineeId;
	}
	public void setTraineeId(Integer traineeId) {
		this.traineeId = traineeId;
	}
	public String getTraineeName() {
		return traineeName;
	}
	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}
	public String getTraineeDomain() {
		return traineeDomain;
	}
	public void setTraineeDomain(String traineeDomain) {
		this.traineeDomain = traineeDomain;
	}
	public String getTraineeLocation() {
		return traineeLocation;
	}
	public void setTraineeLocation(String traineeLocation) {
		this.traineeLocation = traineeLocation;
	}
	@Override
	public String toString() {
		return "Trainee [traineeId=" + traineeId + ", traineeName="
				+ traineeName + ", traineeDomain=" + traineeDomain
				+ ", traineeLocation=" + traineeLocation + "]";
	}
	
	
}
