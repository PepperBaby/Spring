package com.cg.ui;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.dto.Employee;
import com.cg.service.EmployeeService;

public class MyTest {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		ApplicationContext app=
				new ClassPathXmlApplicationContext("spring.xml");
		EmployeeService ee=(EmployeeService) app.getBean("employeeservice");
		
		System.out.println("Employee Id : ");
		int empId=sc.nextInt();
		
		Employee em=ee.getEmpDetail(empId);
		System.out.println(em.toString());
		}

}
