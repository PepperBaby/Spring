package com.cg.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.dto.Employee;
@Component("empdao")
public class EmployeeDao
{
	@Autowired
	Employee emp;
	
	List<Employee> empList;

	public List<Employee> getEmpList() {
		return empList;
	}

	public void setEmpList(List<Employee> empList) {
		this.empList = empList;
	}

	public Employee getEmpDetail(int empId)
	{
		for(Employee empl:empList)
		{
			if(empl.getEmpId()==empId)
			{
				emp=empl;
			}
		}
		return emp;

	}


}
