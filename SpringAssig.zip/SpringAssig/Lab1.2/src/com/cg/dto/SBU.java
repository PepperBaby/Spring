package com.cg.dto;

public class SBU {

	int sbuCode;
	String sbuHead;
	String sbuName;
	public int getSbuCode() {
		return sbuCode;
	}
	public void setSbuCode(int sbuCode) {
		this.sbuCode = sbuCode;
	}
	public String getSbuHead() {
		return sbuHead;
	}
	public void setSbuHead(String sbuHead) {
		this.sbuHead = sbuHead;
	}
	public String getSbuName() {
		return sbuName;
	}
	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}
	
	public String getSBUDetails() {
		return "SBU [sbuCode=" + sbuCode + ", sbuHead=" + sbuHead
				+ ", sbuName=" + sbuName + "]";
	}
	
}
