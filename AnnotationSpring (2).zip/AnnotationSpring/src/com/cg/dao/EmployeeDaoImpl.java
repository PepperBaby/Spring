package com.cg.dao;

import org.springframework.stereotype.Component;

@Component("employeedao")
public class EmployeeDaoImpl implements IEmployeeDao {

	@Override
	public void getMethod() {
		System.out.println("Inside Dao Layer.");

	}

}
