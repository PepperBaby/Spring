package com.cg.dto;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.service.IEmployeeService;

@Component("emp")
public class Employee {

	@Autowired
	IEmployeeService employeeservice;
	public void getDetails(){
		System.out.println("Welcome to spring Annotation...");
		employeeservice.getData();
	}
	public void getData(){
		System.out.println("In getData method");
	}
}
