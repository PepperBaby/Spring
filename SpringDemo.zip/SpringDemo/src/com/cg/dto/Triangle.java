package com.cg.dto;

public class Triangle implements Shape{

	@Override
	public void getShape() {
		System.out.println("In Triangle...");
		
	}

}
