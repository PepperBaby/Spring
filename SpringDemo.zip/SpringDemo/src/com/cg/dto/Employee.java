package com.cg.dto;

public class Employee {

	int empId;
	String empName;
	
	public void getAlldetails(){
		System.out.println("Employee Id is "+empId+".\nEmployee Name is "+empName+".");
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public void getData(){
		System.out.println("In getData method");
	}
}
