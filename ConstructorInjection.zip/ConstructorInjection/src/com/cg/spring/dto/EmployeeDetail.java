package com.cg.spring.dto;

public interface EmployeeDetail {
	
	public void getAllDetails();
}
