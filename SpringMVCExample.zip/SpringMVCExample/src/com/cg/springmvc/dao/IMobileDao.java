package com.cg.springmvc.dao;

import java.util.List;

import com.cg.springmvc.dto.MobileBean;

public interface IMobileDao 
{
	public List<MobileBean> showAllMobile();
	public void deleteMobile(int mobId);
	public void updateMobile(MobileBean mob);
	public List<MobileBean> showMobilebyId(int id);
}
