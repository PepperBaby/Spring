package com.cg.springmvc.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.springmvc.dto.MobileBean;
@Repository("mobileDao")
public class MobileDaoImpl implements IMobileDao {

	@PersistenceContext
	EntityManager em;
	@Override
	public List<MobileBean> showAllMobile() {
		Query queryone=em.createQuery("FROM MobileBean");
		List<MobileBean> myList= queryone.getResultList();
		return myList;
	}

	@Override
	public void deleteMobile(int mobId) {
		Query queryTwo=em.createQuery("DELETE FROM MobileBean WHERE mobId=:mid");
		queryTwo.setParameter("mid", mobId);
		queryTwo.executeUpdate();
	}

	@Override
	public void updateMobile(MobileBean mob) 
	{
		em.merge(mob);
		em.flush();
	}

	@Override
	public List<MobileBean> showMobilebyId(int id)  {
		Query queryone=em.createQuery("SELECT m FROM MobileBean m WHERE mobId=:mid");
		queryone.setParameter("mid", id);
		List<MobileBean> myList= queryone.getResultList();
		return myList;
	}

}
