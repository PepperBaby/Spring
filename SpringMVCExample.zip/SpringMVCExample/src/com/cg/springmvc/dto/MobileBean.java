package com.cg.springmvc.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="mobiledataone")
public class MobileBean 
{
	@Id
	@Column(name="mob_id")
	private Integer mobId;
	
	@Column(name="mob_name")
	private String mobName;
	
	@Column(name="mob_category")
	private String mobCat;
	
	@Column(name="mob_price")
	private Double mobPrice;

	public Integer getMobId() {
		return mobId;
	}

	public void setMobId(Integer mobId) {
		this.mobId = mobId;
	}

	public String getMobName() {
		return mobName;
	}

	public void setMobName(String mobName) {
		this.mobName = mobName;
	}

	public String getMobCat() {
		return mobCat;
	}

	public void setMobCat(String mobCat) {
		this.mobCat = mobCat;
	}

	public Double getMobPrice() {
		return mobPrice;
	}

	public void setMobPrice(Double mobPrice) {
		this.mobPrice = mobPrice;
	}

	public MobileBean() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MobileBean(Integer mobId, String mobName, String mobCat,
			Double mobPrice) {
		this.mobId = mobId;
		this.mobName = mobName;
		this.mobCat = mobCat;
		this.mobPrice = mobPrice;
	}

	@Override
	public String toString() {
		return "MobileBean [mobId=" + mobId + ", mobName=" + mobName
				+ ", mobCat=" + mobCat + ", mobPrice=" + mobPrice + "]";
	}
	
}
