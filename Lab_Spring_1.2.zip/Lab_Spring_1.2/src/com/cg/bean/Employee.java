package com.cg.bean;

public class Employee {

	int empId;
	String empName;
	double empSal;
	String businessUnit;
	int age;
	SBU sbu;
	
	public int getEmpId() {
		return empId;
	}
	public SBU getSbu() {
		return sbu;
	}
	public void setSbu(SBU sbu) {
		this.sbu = sbu;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public double getEmpSal() {
		return empSal;
	}
	public void setEmpSal(double empSal) {
		this.empSal = empSal;
	}
	public String getBusinessUnit() {
		return businessUnit;
	}
	public void setBusinessUnit(String businessUnit) {
		this.businessUnit = businessUnit;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public void dispEmpDetails()
	{
		System.out.println("Employee details");
		System.out.println("-------------------------");
		System.out.println("Employee [empId=" + empId + ", empName=" + empName
				+ ", empSal=" + empSal + ", businessUnit=" + businessUnit
				+ ", age=" + age + "]");
		
		System.out.println("SBU Details = "+sbu.getSBUDetails());
		
	}
}
