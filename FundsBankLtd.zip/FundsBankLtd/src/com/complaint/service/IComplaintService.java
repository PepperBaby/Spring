package com.complaint.service;

import com.complaint.bean.ComplaintBean;
import com.complaint.exception.ComplaintException;

public interface IComplaintService {
	public int addComplaintDetails(ComplaintBean bean) throws ComplaintException;
	public ComplaintBean checkStatus(int complaintId)
			throws ComplaintException;
}
