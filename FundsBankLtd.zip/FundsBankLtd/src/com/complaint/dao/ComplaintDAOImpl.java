package com.complaint.dao;


import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.complaint.bean.ComplaintBean;
import com.complaint.exception.ComplaintException;



@Repository
@Transactional
public class ComplaintDAOImpl implements IComplaintDAO {
	
	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public int addComplaintDetails(ComplaintBean bean)
			throws ComplaintException {
		int id=0;
		
		
		try {
		
		
			entityManager.persist(bean);
			entityManager.flush();
			id=bean.getComplaintId();
		} catch (Exception e) {
			throw new ComplaintException("unable to persist in Dao Layer" +e.getMessage());
		}
		
		return id;
	}

	@Override
	public ComplaintBean checkStatus(int complaintId)
			throws ComplaintException {
		ComplaintBean bean;
		try {
			
			bean=entityManager.find(ComplaintBean.class, complaintId);
			
		} catch (Exception e) {
			throw new ComplaintException("unable to Search records in Dao layer"+ e.getMessage());
		}
		return bean;
		
	}

}
