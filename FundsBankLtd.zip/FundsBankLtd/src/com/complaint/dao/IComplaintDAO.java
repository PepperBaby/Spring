package com.complaint.dao;

import java.util.List;

import com.complaint.bean.ComplaintBean;
import com.complaint.exception.ComplaintException;

public interface IComplaintDAO {

	public int addComplaintDetails(ComplaintBean bean) throws ComplaintException;
	
	public ComplaintBean checkStatus(int complaintId) throws ComplaintException;
}
