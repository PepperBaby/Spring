package com.cg.service;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

@Aspect
public class LoginAdvice
{
	@Before("execution(public void getLogin()")
	public void beforeLogin()
	{
		System.out.println("Before get Login");
	}
	
	@After("execution(public void getLogin()")
	public void afterLogin()
	{
		System.out.println("After get Login");
	}
}
