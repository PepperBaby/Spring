package com.cg.service;

public class Login
{
	public void getLogin()
	{
		System.out.println("Hiii login");
	}
}
