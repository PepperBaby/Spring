package com.cg.service;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MyTest
{
	public static void main(String args[])
	{
		ApplicationContext app=new ClassPathXmlApplicationContext("spring.xml");
		Login lo=(Login) app.getBean("login");
		lo.getLogin();
	}
}
