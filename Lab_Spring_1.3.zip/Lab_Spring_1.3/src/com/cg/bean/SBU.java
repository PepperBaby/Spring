package com.cg.bean;

import java.util.List;

public class SBU {

	int sbuId;
	String sbuName;
	String sbuHead;
	List<Employee> emp;
	
	public int getSbuId() {
		return sbuId;
	}
	public void setSbuId(int sbuId) {
		this.sbuId = sbuId;
	}
	public String getSbuName() {
		return sbuName;
	}
	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}
	public String getSbuHead() {
		return sbuHead;
	}
	public void setSbuHead(String sbuHead) {
		this.sbuHead = sbuHead;
	}
	public List<Employee> getEmp() {
		return emp;
	}
	public void setEmp(List<Employee> emp) {
		this.emp = emp;
	}
	public SBU() {
		super();
		// TODO Auto-generated constructor stub
	}
	public void getSBUDetails() {
		System.out.println("SBU details");
		System.out.println("-------------------------");
		System.out.println("SBU [sbuId=" + sbuId + ", sbuName=" + sbuName + ", sbuHead="
				+ sbuHead + "]"); 
		System.out.println("Employee details");
		System.out.println("-------------------------");
		for(Employee e:emp)
		{
			System.out.println(e.toString());
		}
	}
	
}
