package com.cg.lab2.service;

import java.util.List;

import com.cg.lab2.dto.Trainee;

public interface ITraineeService {

	public int addTraineeInfo(Trainee trainee);
	public void deleteTrainee(int traineeId);
	public void modifyTrainee(Trainee trainee);
	public Trainee showTrainee(int traineeId);
	public List<Trainee> showAllTrainees();
	public boolean validateId(Integer id);
}
