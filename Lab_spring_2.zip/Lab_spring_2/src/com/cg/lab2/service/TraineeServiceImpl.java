package com.cg.lab2.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.lab2.dao.ITraineeDao;
import com.cg.lab2.dto.Trainee;

@Service("traineeservice")
@Transactional //DML statement applicable due to this annotation
public class TraineeServiceImpl implements ITraineeService {

	@Autowired
	ITraineeDao traineedao;
	
	@Override
	public int addTraineeInfo(Trainee trainee) {
	
		return traineedao.addTraineeInfo(trainee);
	}

	@Override
	public void deleteTrainee(int traineeId) {
		traineedao.deleteTrainee(traineeId);
	}

	@Override
	public void modifyTrainee(Trainee trainee) {
		traineedao.modifyTrainee(trainee);
	}

	@Override
	public Trainee showTrainee(int traineeId) {
		return traineedao.showTrainee(traineeId);
	}

	@Override
	public List<Trainee> showAllTrainees() {
		return traineedao.showAllTrainees();
	}
	
	@Override
	public boolean validateId(Integer id)
	{
		List<Integer> getIds=traineedao.retrieveAllIds();
		for(Integer i:getIds)
		{
			if(id==i)
				return true;
		}
		return false;
	} 

}
