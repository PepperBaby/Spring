package com.cg.lab2.ctrl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.lab2.dto.Trainee;
import com.cg.lab2.service.ITraineeService;


@Controller
public class TranController {
	
	@Autowired
	ITraineeService traineeservice;
	
	@RequestMapping(value="login",method=RequestMethod.GET)
	public String getAll(@RequestParam("userName")String name,@RequestParam("userPwd")String pwd )
	{
		if(name.equals("admin") && pwd.equals("admin"))
		{
			return "home";
		}
		else 
		return "invalid";
	}
	
	/********** Insert Start*************************/
	@RequestMapping(value="add",method=RequestMethod.GET)
	public String addTrainee(@ModelAttribute("my") Trainee trainee,
			Map<String,Object> model)
	{
		List<String> myDomain = new ArrayList<>();
		myDomain.add("Please Select");
		myDomain.add("JEE");
		myDomain.add("Oracle");
		myDomain.add(".NET");
		model.put("domain", myDomain);
		return "addTrainee";
	}
	
	@RequestMapping(value="insertdata", method=RequestMethod.POST)
	public ModelAndView insertTraineeDetails(@Valid @ModelAttribute("my") Trainee trainee,
			BindingResult result,
			Map<String,Object> model)
	{
		int id=0;
		if(result.hasErrors())
		{
			List<String> myDomain = new ArrayList<>();
			myDomain.add("Please Select");
			myDomain.add("JEE");
			myDomain.add("Oracle");
			myDomain.add(".NET");
			model.put("domain", myDomain);
			return new ModelAndView("addTrainee");
		}
		else
		{
			id= traineeservice.addTraineeInfo(trainee);
		}
		return new ModelAndView("success", "trandata", id);
	} 
	/********** Insert End*************************/
	
	/********** Delete Start*************************/
	@RequestMapping(value="delete",method=RequestMethod.GET)
	public String search(@ModelAttribute("my") Trainee trainee)
	{
		return "delete";
	}
	
	@RequestMapping(value="deletedata",method=RequestMethod.GET)//'all' is url
	public ModelAndView delete1(@RequestParam("tranId")Integer traineeId)
	{
		
		Trainee trainee=traineeservice.showTrainee(traineeId);
		
		return new ModelAndView("delete","temp",trainee);	
	}
	
	@RequestMapping(value="deletesuccess",method=RequestMethod.GET)//'all' is url
	public String delete2(@RequestParam("id")Integer traineeId)
	{
		traineeservice.deleteTrainee(traineeId);
		return "deletesuccess";
	}
	/********** Delete End*************************/

	
	/********** Modify Start*************************/
	@RequestMapping(value="modify", method=RequestMethod.GET)
	public String modifyData(@ModelAttribute("my")Trainee trainee)
	{		
		return "modify";
	}
	
	@RequestMapping(value="modifydata", method=RequestMethod.GET)
	public ModelAndView modifyDataAll(@RequestParam("tranId")int traineeId,
			@ModelAttribute("my")Trainee trainee)
	{
		trainee=traineeservice.showTrainee(traineeId);
		return new ModelAndView("modify","temp", trainee);
	}

	@RequestMapping(value="update", method=RequestMethod.POST)
	public String update(@ModelAttribute("my")Trainee trainee)
	{
		System.out.println(trainee);
		traineeservice.modifyTrainee(trainee);
		return "updatesuccess";
	}
	/********** Modify End*************************/

	/********** Retrieve Start*************************/
	@RequestMapping(value="show", method=RequestMethod.GET)
	public String searchTrainee()
	{
		return "search";
	}
	@RequestMapping(value="searchdata", method=RequestMethod.GET)
	public ModelAndView search(@ModelAttribute("my")Trainee trainee,
			@RequestParam("tranId")int traineeId)
	{
		if(traineeservice.validateId(traineeId))
		{
		trainee=traineeservice.showTrainee(traineeId);
		return new ModelAndView("search", "temp", trainee);
		}
		return new ModelAndView("searcherror","temp", traineeId);
	}
	/********** Retrieve End*************************/
	
	/********** Retrieve All Start*************************/
	@RequestMapping(value="showall", method=RequestMethod.GET)
	public ModelAndView searchData(@ModelAttribute("my")Trainee trainee)
	{
		List<Trainee> searched=traineeservice.showAllTrainees();
		for(Trainee t:searched)
		{
			System.out.println(t);
		}
		return new ModelAndView("searchall", "temp", searched);
	}
	/********** Retrieve All End*************************/

}
