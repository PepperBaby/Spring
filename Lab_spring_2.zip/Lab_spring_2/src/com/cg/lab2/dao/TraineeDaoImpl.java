package com.cg.lab2.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.lab2.dto.Trainee;

@Repository("traineedao")
public class TraineeDaoImpl implements ITraineeDao {

	@PersistenceContext
	EntityManager entitymanager;
	
	@Override
	public int addTraineeInfo(Trainee trainee) {
		entitymanager.persist(trainee);
		entitymanager.flush();;
		return trainee.getTraineeId();
	}

	@Override
	public void deleteTrainee(int traineeId) {
		Query q3 = entitymanager.createQuery("DELETE FROM Trainee where traineeId=:tid");
		q3.setParameter("tid", traineeId);
		q3.executeUpdate();	
	}

	@Override
	public void modifyTrainee(Trainee trainee) {
		entitymanager.merge(trainee);
	}

	@Override
	public Trainee showTrainee(int traineeId) {
		Trainee tran = entitymanager.find(Trainee.class, traineeId);
		return tran;
	}

	@Override
	public List<Trainee> showAllTrainees() {
		Query queryOne = entitymanager.createQuery("FROM Trainee");
		//List<Trainee> myList = queryOne.getResultList();
		return queryOne.getResultList();
	}
	
	@Override
	public List<Integer> retrieveAllIds() {
		String q1="SELECT trainee.traineeId FROM Trainee trainee";
		Query query1=entitymanager.createQuery(q1);
		return query1.getResultList();
	} 

}
