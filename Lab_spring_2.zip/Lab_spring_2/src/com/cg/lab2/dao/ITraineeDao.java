package com.cg.lab2.dao;

import java.util.List;

import com.cg.lab2.dto.Trainee;

public interface ITraineeDao {

	public int addTraineeInfo(Trainee trainee);
	public void deleteTrainee(int traineeId);
	public void modifyTrainee(Trainee trainee);
	public Trainee showTrainee(int traineeId);
	public List<Trainee> showAllTrainees();
	public List<Integer> retrieveAllIds();
}
