package com.cg.springboot.dto;

import org.springframework.stereotype.Component;

@Component("proj")
public class Project {

	public void getDate(){
		System.out.println("Welcome to Spring Boot!");
	}
}
